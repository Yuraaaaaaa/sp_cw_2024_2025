#define _CRT_SECURE_NO_WARNINGS

#include "stdio.h"

int data[8192] = {0};
int contextStack[8192] = {0}, contextStackIndex = 0;
int opStack[8192] = {0}, opStackIndex = 0, opTemp = 0;
int lastBindDataIndex = 0;

int main() {
    contextStackIndex = 0;
    opStackIndex = 0;
    opTemp = 0;
    lastBindDataIndex = 0;

    //";"

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"GET"
    (void)scanf_s("%d", &opTemp);
    data[opStack[opStackIndex]] = opTemp, opStackIndex = 0;

    //null statement (non-context)

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"+"
    opTemp = opStack[opStackIndex - 1] += opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"FOR"

    //"16"
    opStack[++opStackIndex] = opTemp = 0x00000010;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"TO" (after "FOR")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF79672C6C8:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"DO" (after "TO" after "FOR")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF79672ADD8;
    ++opStack[contextStack[contextStackIndex]];

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"FOR"

    //"20"
    opStack[++opStackIndex] = opTemp = 0x00000014;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"TO" (after "FOR")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF796731198:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"DO" (after "TO" after "FOR")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF79672F8A8;
    ++opStack[contextStack[contextStackIndex]];

    //"IF"

    //"_DEVID"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"2"
    opStack[++opStackIndex] = opTemp = 0x00000002;

    //"GT"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] >= opStack[opStackIndex--];

    //after cond expresion (after "IF")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF796733700;

    //";" (after "then"-part of IF-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF796733700:

    //"ELSE"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF796734378;

    //"GOTO" previous ident "_ENDCB"(as label)
    goto LABEL__00000237A0B44518;

    //null statement (non-context)

    //";" (after "ELSE")
    LABEL__AFTER_ELSE_00007FF796734378:

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"FOR"

    //"24"
    opStack[++opStackIndex] = opTemp = 0x00000018;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"TO" (after "FOR")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF796738A20:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"DO" (after "TO" after "FOR")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF796737130;
    ++opStack[contextStack[contextStackIndex]];

    //"IF"

    //"_REMAI"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"_DEVID"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"GT"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] >= opStack[opStackIndex--];

    //after cond expresion (after "IF")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF79673AF88;

    //";" (after "then"-part of IF-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF79673AF88:

    //"ELSE"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF79673BC00;

    //"GOTO" previous ident "_ENDCC"(as label)
    goto LABEL__00000237A0B2F358;

    //null statement (non-context)

    //";" (after "ELSE")
    LABEL__AFTER_ELSE_00007FF79673BC00:

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"_REMAI"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"_DEVID"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "FOR")
    goto LABEL__AFTER_TO_00007FF796738A20;
    LABEL__EXIT_FOR_00007FF796737130:
    --contextStackIndex;

    //ident "_ENDCC"(as label) previous ":"
    LABEL__00000237A0B2F358:

    //"IF"

    //"_REMAI"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"=="
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] == opStack[opStackIndex--];

    //after cond expresion (after "IF")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF796741770;

    //"GOTO" previous ident "_ENDCB"(as label)
    goto LABEL__00000237A0B44518;

    //null statement (non-context)

    //";" (after "then"-part of IF-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF796741770:

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_DEVID"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "FOR")
    goto LABEL__AFTER_TO_00007FF796731198;
    LABEL__EXIT_FOR_00007FF79672F8A8:
    --contextStackIndex;

    //ident "_ENDCB"(as label) previous ":"
    LABEL__00000237A0B44518:

    //"IF"

    //"_DEVID"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"=="
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] == opStack[opStackIndex--];

    //after cond expresion (after "IF")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF796747708;

    //"GOTO" previous ident "_ENDCA"(as label)
    goto LABEL__00000237A0B2F088;

    //null statement (non-context)

    //";" (after "then"-part of IF-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF796747708:

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"+"
    opTemp = opStack[opStackIndex - 1] += opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "FOR")
    goto LABEL__AFTER_TO_00007FF79672C6C8;
    LABEL__EXIT_FOR_00007FF79672ADD8:
    --contextStackIndex;

    //ident "_ENDCA"(as label) previous ":"
    LABEL__00000237A0B2F088:

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"PUT"
    (void)printf("%d\r\n", opTemp = opStack[opStackIndex]), opStackIndex = 0;

    //null statement (non-context)

    return 0;
}