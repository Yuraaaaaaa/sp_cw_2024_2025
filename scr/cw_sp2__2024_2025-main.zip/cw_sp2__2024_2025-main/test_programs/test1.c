#define _CRT_SECURE_NO_WARNINGS

#include "stdio.h"

int data[8192] = {0};
int contextStack[8192] = {0}, contextStackIndex = 0;
int opStack[8192] = {0}, opStackIndex = 0, opTemp = 0;
int lastBindDataIndex = 0;

int main() {
    contextStackIndex = 0;
    opStackIndex = 0;
    opTemp = 0;
    lastBindDataIndex = 0;

    //";"

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"GET"
    (void)scanf_s("%d", &opTemp);
    data[opStack[opStackIndex]] = opTemp, opStackIndex = 0;

    //null statement (non-context)

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"FOR"

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"TO" (after "FOR")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF79672A588:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"DO" (after "TO" after "FOR")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF796728C98;
    ++opStack[contextStack[contextStackIndex]];

    //"IF"

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"!="
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] != opStack[opStackIndex--];

    //after cond expresion (after "IF")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF79672CAF0;

    //";" (after "then"-part of IF-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF79672CAF0:

    //"ELSE"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF79672D768;

    //"GOTO" previous ident "_ENDCY"(as label)
    goto LABEL__000001DAE36795D8;

    //null statement (non-context)

    //";" (after "ELSE")
    LABEL__AFTER_ELSE_00007FF79672D768:

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_RESUL"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"*"
    opTemp = opStack[opStackIndex - 1] *= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VALUE"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "FOR")
    goto LABEL__AFTER_TO_00007FF79672A588;
    LABEL__EXIT_FOR_00007FF796728C98:
    --contextStackIndex;

    //ident "_ENDCY"(as label) previous ":"
    LABEL__000001DAE36795D8:

    //"_RESUL"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"PUT"
    (void)printf("%d\r\n", opTemp = opStack[opStackIndex]), opStackIndex = 0;

    //null statement (non-context)

    return 0;
}