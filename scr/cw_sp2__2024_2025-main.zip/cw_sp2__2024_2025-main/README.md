# cw_sp2__2024_2025
# ~99,58% completed
